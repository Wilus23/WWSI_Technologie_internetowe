<html>
  <head>
  
  </head>
  <body>
     <p>Witaj
       <?php
            session_start();	   
			echo $_SESSION['user']; 
	   ?>
	 </p>
     <p><pre>dfgjdshkgfh
		kjhfdg;ksjhdgf;lk
		lkdsfglk
		lkdfglkj;'dsj'fg;l</pre>
	 </p>	
		
  </body>
  
</html>